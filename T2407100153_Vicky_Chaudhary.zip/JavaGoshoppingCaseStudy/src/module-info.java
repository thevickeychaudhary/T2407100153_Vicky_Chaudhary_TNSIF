/**
 * 
 */
/**
 * 
 */
module FrameworkForOnlineShoppingApplication {
}